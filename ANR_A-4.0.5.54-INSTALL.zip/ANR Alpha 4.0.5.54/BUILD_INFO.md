# Adaptive Networks Remain Alpha 4.0.5.54

```json
{
  "schema": 1,
  "name": "Adaptive Networks Remain Alpha",
  "version": "4.0.5.54",
  "channel": "Alpha",
  "configuration": "Debug",
  "source_commit": "66969a944cb6b6f8fffcae23eea4d09619aa7edf",
  "kiancommons_commit": "9edb71664bfc333cd6aecca6f503d187e58b58ea",
  "kiancommons_repository": "SirSheikhsPears/KianCommons",
  "source_state": "dirty",
  "build_utc": "2026-11-24T21:30:03Z",
  "toolchain": "MSBuild 18.10.1, SDK 10.0.401, Roslyn target a1c9c8bc54d3443e3a3a918e7384f2a8d4593534e096c5930d0cf96fb628b8f1",
  "game_assemblies": [
    {
      "file": "Assembly-CSharp.dll",
      "sha256": "ea319ca84d96ea004fc413762370ae32f08279ed9ee6b164be97016b05265fad",
      "assembly_version": "0.0.0.0"
    },
    {
      "file": "ColossalManaged.dll",
      "sha256": "661d8401e0b4c6bbef6c414e5f78b0a18d6f8a2a719b81a0f19181802a9d4ac7",
      "assembly_version": "0.3.0.0"
    },
    {
      "file": "ICities.dll",
      "sha256": "d08c742eca81feeb45607c5fb80258a7560251349d37331efa92cd9de5300a18",
      "assembly_version": "1.21.0.0"
    },
    {
      "file": "UnityEngine.dll",
      "sha256": "879924003f092619e29ba6da93f599e82df671868494ae1b32927d9d5b3fd66d",
      "assembly_version": "0.0.0.0"
    },
    {
      "file": "UnityEngine.UI.dll",
      "sha256": "7d8093c850bd6d034796770c01489e00ab610bf95ad73484df605d89c53a15df",
      "assembly_version": "1.0.0.0"
    }
  ],
  "dll_sha256": "4fdb4f0c45328372fc96f1766b6d6f609ac60e72f58c30730303c54f6ddbc502",
  "payload": [
    {
      "file": "AdaptiveRoads.dll",
      "bytes": 985600,
      "sha256": "4fdb4f0c45328372fc96f1766b6d6f609ac60e72f58c30730303c54f6ddbc502"
    },
    {
      "file": "AdaptiveRoads.dll.mdb",
      "bytes": 458188,
      "sha256": "fe5cc171822cf42978b01d8e87e85642ab5194e657275ce1493959284b67b3ba"
    },
    {
      "file": "CitiesHarmony.API.dll",
      "bytes": 12288,
      "sha256": "441a27dc196acbc756b05e8b8e7e9297d75510ed2372d9087f9dbfcd7936a244"
    },
    {
      "file": "FbxFormatConverter.exe",
      "bytes": 8035328,
      "sha256": "283711354050abbc6c0bd6db64a68b7c2339b22f7189cb0b29ae291b63310a56"
    },
    {
      "file": "NS.Helpers.dll",
      "bytes": 9728,
      "sha256": "7e167b23a7e982b38aa169502c6b0bc20212efbb9cb159ef308fc268ecdc80ba"
    },
    {
      "file": "NS.png",
      "bytes": 763,
      "sha256": "9777bc209bfa8538574978a9ce80cc9450b5fc2bd5e017fa1f0778ef68d00681"
    },
    {
      "file": "PrefabMetadata.dll",
      "bytes": 11776,
      "sha256": "ce3282b101218fb932b1fecff7095ce344732690425a66e8f3074565ad9a48f5"
    },
    {
      "file": "PrefabMetadataAPI.dll",
      "bytes": 4096,
      "sha256": "3089f85557d31971c9b2f723d48bf8c8ca4cd86e8aa0325dc1530425ff65e015"
    },
    {
      "file": "PreviewImage.png",
      "bytes": 23859,
      "sha256": "87dfa8d79835bf7aaad40e4d07a375ca0aa37ec12d0bd4e56eef28a5c9480261"
    },
    {
      "file": "UnifiedUILib.dll",
      "bytes": 177664,
      "sha256": "6b5b473556457a897224ad64d7e80215fed2e1ddd5c3870a37e34b4d2b15e43a"
    },
    {
      "file": "uui_ar.png",
      "bytes": 1102,
      "sha256": "4ec97b19f5d778fe2577062843f536c8b951ca84a2589ca582aa66f10809d737"
    },
    {
      "file": "uui_vbs.png",
      "bytes": 2002,
      "sha256": "f4498d97cf14dcc777709e4d5b10d77061d1f0df0c637af446dba8c622e79ea4"
    }
  ]
}
```
