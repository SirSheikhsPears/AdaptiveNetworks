# Adaptive Networks Remain Alpha 4.0.5.43

Paczkę przygotowano po kompilacji. Wynik testów gry właściciel zatwierdza osobno.

```json
{
  "schema": 1,
  "name": "Adaptive Networks Remain Alpha",
  "version": "4.0.5.43",
  "channel": "Alpha",
  "configuration": "Debug",
  "source_commit": "cdc48409a20e0a86b556c4670a496b3b0b3fcd0f",
  "kiancommons_commit": "9edb71664bfc333cd6aecca6f503d187e58b58ea",
  "kiancommons_repository": "SirSheikhsPears/KianCommons",
  "source_state": "clean",
  "build_utc": "2026-11-03T15:07:07Z",
  "toolchain": "MSBuild 18.10.1, SDK 10.0.401, Roslyn target a1c9c8bc54d3443e3a3a918e7384f2a8d4593534e096c5930d0cf96fb628b8f1",
  "game_assemblies": [
    {
      "file": "Assembly-CSharp.dll",
      "sha256": "df557994a03c93d8bb4a14f80b1fbcc0fb29d547658442445d078d069bcdd9fe",
      "assembly_version": "0.0.0.0"
    },
    {
      "file": "ColossalManaged.dll",
      "sha256": "34701f61def31f5f9df79d573ce19e0bc52575879bcc395d51b39f6d746a58b9",
      "assembly_version": "0.3.0.0"
    },
    {
      "file": "ICities.dll",
      "sha256": "466586adb50dcc2e1382d9f7683fa50feba82a376d736fb65f1c34a53d0b9c90",
      "assembly_version": "1.17.0.0"
    },
    {
      "file": "UnityEngine.dll",
      "sha256": "879924003f092619e29ba6da93f599e82df671868494ae1b32927d9d5b3fd66d",
      "assembly_version": "0.0.0.0"
    },
    {
      "file": "UnityEngine.UI.dll",
      "sha256": "7d8093c850bd6d034796770c01489e00ab610bf95ad73484df605d89c53a15df",
      "assembly_version": "1.0.0.0"
    }
  ],
  "dll_sha256": "e26b9b84c2dcc5c6dac2b22b20c56eea132709fb349b65dfe7cf28d1189ee64e",
  "payload": [
    {
      "file": "AdaptiveRoads.dll",
      "bytes": 970240,
      "sha256": "e26b9b84c2dcc5c6dac2b22b20c56eea132709fb349b65dfe7cf28d1189ee64e"
    },
    {
      "file": "AdaptiveRoads.dll.mdb",
      "bytes": 452799,
      "sha256": "a354643c4be54940d8b93c8ad742c52cca6766a294c430f2fff55a2fd027a676"
    },
    {
      "file": "CitiesHarmony.API.dll",
      "bytes": 12288,
      "sha256": "441a27dc196acbc756b05e8b8e7e9297d75510ed2372d9087f9dbfcd7936a244"
    },
    {
      "file": "FbxFormatConverter.exe",
      "bytes": 8035328,
      "sha256": "283711354050abbc6c0bd6db64a68b7c2339b22f7189cb0b29ae291b63310a56"
    },
    {
      "file": "NS.Helpers.dll",
      "bytes": 9728,
      "sha256": "7e167b23a7e982b38aa169502c6b0bc20212efbb9cb159ef308fc268ecdc80ba"
    },
    {
      "file": "NS.png",
      "bytes": 763,
      "sha256": "9777bc209bfa8538574978a9ce80cc9450b5fc2bd5e017fa1f0778ef68d00681"
    },
    {
      "file": "PrefabMetadata.dll",
      "bytes": 11776,
      "sha256": "1ef173b0b3a3186dc46e6f76f4bd8f33a9d1b61b90f12a82cbf5846d4b7f8cd4"
    },
    {
      "file": "PrefabMetadataAPI.dll",
      "bytes": 4096,
      "sha256": "dc7fd74c179205c4df2d0a6d22326f8556fb6a7771ea7101ca7adad20c7e6e59"
    },
    {
      "file": "PreviewImage.png",
      "bytes": 23859,
      "sha256": "87dfa8d79835bf7aaad40e4d07a375ca0aa37ec12d0bd4e56eef28a5c9480261"
    },
    {
      "file": "UnifiedUILib.dll",
      "bytes": 177664,
      "sha256": "6b5b473556457a897224ad64d7e80215fed2e1ddd5c3870a37e34b4d2b15e43a"
    },
    {
      "file": "uui_ar.png",
      "bytes": 1102,
      "sha256": "4ec97b19f5d778fe2577062843f536c8b951ca84a2589ca582aa66f10809d737"
    },
    {
      "file": "uui_vbs.png",
      "bytes": 2002,
      "sha256": "f4498d97cf14dcc777709e4d5b10d77061d1f0df0c637af446dba8c622e79ea4"
    }
  ]
}
```
